# Ghost Minimalist Theme
A minimalist Ghost theme for your personal portfolio.
